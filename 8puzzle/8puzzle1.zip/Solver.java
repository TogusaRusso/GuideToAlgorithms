public class Solver {
  
  private class SearchNode implements Comparable<SearchNode> {
    Board      board;
    int        moves;
    SearchNode prev;
    SearchNode(Board b, int m, SearchNode p) {
      board = b;
      moves = m;
      prev = p;
    }
    
    public int compareTo(SearchNode that) { 
      int priorityP = this.board.manhattan() + this.moves;
      int priorityQ = that.board.manhattan() + that.moves;
      if      (priorityP < priorityQ)
        return -1;
      else if (priorityP > priorityQ)
        return 1;
      else {
        priorityP = this.board.hamming() + this.moves;
        priorityQ = that.board.hamming() + that.moves;
        if      (priorityP < priorityQ)
          return -1;
        else if (priorityP > priorityQ)
          return 1;
        else
          return 0;
      }
    }
  }
  private SearchNode currentMain;
  private SearchNode currentTwin;
  
  public Solver(Board initial) {           // find a solution to the initial board (using the A* algorithm)
    if (initial == null)
      throw new java.lang.NullPointerException();

    MinPQ<SearchNode> mainPQ = new MinPQ<SearchNode>();
    MinPQ<SearchNode> twinPQ = new MinPQ<SearchNode>();
    
    mainPQ.insert(new SearchNode(initial,        0, null));
    twinPQ.insert(new SearchNode(initial.twin(), 0, null));
    while(true) {
      currentMain = mainPQ.delMin();
      currentTwin = twinPQ.delMin();
      if (currentMain.board.isGoal() || currentTwin.board.isGoal())
        break;
      Iterable<Board> neighborsMain = currentMain.board.neighbors();
      for (Board neighbor : neighborsMain) {
        if (currentMain.prev != null)
          if (neighbor.equals(currentMain.prev.board))
            continue;
        mainPQ.insert(new SearchNode(neighbor, currentMain.moves + 1, currentMain));
      }
      Iterable<Board> neighborsTwin = currentTwin.board.neighbors();
      for (Board neighbor : neighborsTwin) {
        if (currentTwin.prev != null)
          if (neighbor.equals(currentTwin.prev.board))
            continue;
        twinPQ.insert(new SearchNode(neighbor, currentTwin.moves + 1, currentTwin));
      }
    }
  }
  
  public boolean isSolvable() {            // is the initial board solvable?
    return currentMain.board.isGoal();
  }
  
  public int moves() {                     // min number of moves to solve initial board; -1 if unsolvable
    if (isSolvable()) 
      return currentMain.moves;
    else
      return -1;
  }
  
  public Iterable<Board> solution() {      // sequence of boards in a shortest solution; null if unsolvable
    if (!isSolvable()) 
      return null;
    Stack<Board> sol = new Stack<Board>();
    SearchNode position = currentMain;
    while (position != null) {
      sol.push(position.board);
      position = position.prev;
    }
    return sol;
  }
  
  // solve a slider puzzle (given below)
  public static void main(String[] args) {
    // create initial board from file
    In in = new In(args[0]);
    int N = in.readInt();
    int[][] blocks = new int[N][N];
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            blocks[i][j] = in.readInt();
    Board initial = new Board(blocks);

    // solve the puzzle
    Solver solver = new Solver(initial);

    // print solution to standard output
    if (!solver.isSolvable())
        StdOut.println("No solution possible");
    else {
        StdOut.println("Minimum number of moves = " + solver.moves());
        for (Board board : solver.solution())
            StdOut.println(board);
    }
  }
}